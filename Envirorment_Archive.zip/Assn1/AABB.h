#pragma once
class AABB
{

};

class CircleAABB : AABB
{

};

class RectAABB : AABB
{

};
