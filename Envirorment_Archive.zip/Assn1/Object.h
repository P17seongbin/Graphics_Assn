#pragma once
class Object
{
public:

	Object();
	~Object();
};

