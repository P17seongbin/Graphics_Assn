#include "Assn1.h"

void ReShape(int w, int h)
{
	glLoadIdentity(); //Stack matrix = I
	gluOrtho2D(0.0, WIN_HOR, 0.0, WIN_VER);
	glViewport(0, 0, w, h);
}

void setOrtho2D(GameManager* GM,KeyHandler* keyhandler)
{
	glLoadIdentity();
	if (keyhandler->isAsciiKeyPressed('x'))
	{
		std::pair<float, float> pos = GM->findObjectwithTag("ball")->getPos();//���̶�� �±׸� ���� ������Ʈ�� �����ɴϴ�.
		float size = CAM_SIZE;
		pos = make_pair(
			MAX(MIN(WIN_HOR - size, pos.first), size),
			MAX(MIN(WIN_VER - size, pos.second), size)
		);
		gluOrtho2D(pos.first - size, pos.first + size, pos.second - size, pos.second + size);
	}
	else
		gluOrtho2D(0.0, WIN_HOR, 0.0, WIN_VER);
}